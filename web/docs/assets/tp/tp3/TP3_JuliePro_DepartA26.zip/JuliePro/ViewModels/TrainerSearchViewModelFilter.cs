﻿using System.ComponentModel.DataAnnotations;
using JuliePro.Models;

namespace JuliePro.ViewModels
{
    public class TrainerSearchViewModelFilter
    {
        [Display(Name = "SearchNameText")]
        public string? SearchNameText { get; set; }
        
        [Display(Name = "SelectedDisciplineId")]
        public int? SelectedDisciplineId { get; set; }

        [Display(Name = "SelectedCertificationId")]
        public int? SelectedCertificationId { get; set; }

        [Display(Name = "SelectedCertificationCenter")]
        public string? SelectedCertificationCenter { get; set; }

        [Display(Name = "SelectedGenre")]
        public Genre? SelectedGender { get; set; }

        [Display(Name = "SelectedPageSize")]
        [Range(3, 30, ErrorMessage = "{0} should be between {1} and {2}")]
        public int SelectedPageSize { get; set; }

        [Display(Name = "SelectedPageIndex")]
        public int SelectedPageIndex { get; set; }

        public void VerifyProperties()
        {
            SelectedDisciplineId = SelectedDisciplineId == 0 ? null : SelectedDisciplineId;
            SelectedCertificationId = SelectedCertificationId == 0 ? null : SelectedCertificationId;
            SelectedPageSize = SelectedPageSize == 0 ? 9 : SelectedPageSize;
            SelectedPageIndex = SelectedPageIndex;
            SelectedGender = SelectedGender;
            SearchNameText = SearchNameText?.Trim() == string.Empty ? null : SearchNameText;
            SelectedCertificationCenter = SelectedCertificationCenter?.Trim() == string.Empty ? null : SelectedCertificationCenter;
        }
    }
}
