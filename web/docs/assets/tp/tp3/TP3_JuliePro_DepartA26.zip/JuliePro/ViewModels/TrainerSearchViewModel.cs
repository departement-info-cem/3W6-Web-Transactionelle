﻿using JuliePro.Models;
using JuliePro.Services;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace JuliePro.ViewModels
{

    /// <summary>
    /// Le TrainerSearchViewModelFilter contient la partie du formulaire. 
    /// Le TrainerSearchViewModel contient le reste
    /// </summary>
    public class TrainerSearchViewModel : TrainerSearchViewModelFilter
    {

        public TrainerSearchViewModel()
        {

        }

        public TrainerSearchViewModel(TrainerSearchViewModelFilter filter)
        {
            SelectedDisciplineId = filter.SelectedDisciplineId;
            SelectedCertificationId = filter.SelectedCertificationId;
            SelectedPageSize = filter.SelectedPageSize ;
            SelectedPageIndex = filter.SelectedPageIndex;
            SelectedGender = filter.SelectedGender;
            SearchNameText = filter.SearchNameText;
            SelectedCertificationCenter = filter.SelectedCertificationCenter;
            VerifyProperties();
        }

        [Display(Name = "Items")]
        public PaginatedList<Trainer> Items { get; set; }
        
        [Display(Name = "Disciplines")]
        public SelectList Disciplines { get; set; }
        
        [Display(Name = "Certifications")]
        public SelectList Certifications { get; set; }
        
        [Display(Name = "CertificationCenters")]
        public SelectList CertificationCenters { get; set; }
        
        [Display(Name = "AvailablePageSizes")]
        public SelectList AvailablePageSizes { get; set; }
    }
}
