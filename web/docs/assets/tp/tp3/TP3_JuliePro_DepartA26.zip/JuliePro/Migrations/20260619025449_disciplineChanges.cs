﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JuliePro.Migrations
{
    /// <inheritdoc />
    public partial class disciplineChanges : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Disciplines_Disciplines_Parent_Id",
                table: "Disciplines");

            migrationBuilder.DropIndex(
                name: "IX_Disciplines_Parent_Id",
                table: "Disciplines");

            migrationBuilder.DropColumn(
                name: "Parent_Id",
                table: "Disciplines");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Parent_Id",
                table: "Disciplines",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Disciplines_Parent_Id",
                table: "Disciplines",
                column: "Parent_Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Disciplines_Disciplines_Parent_Id",
                table: "Disciplines",
                column: "Parent_Id",
                principalTable: "Disciplines",
                principalColumn: "Id");
        }
    }
}
